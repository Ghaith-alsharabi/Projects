from flask import Blueprint

bp = Blueprint("basketballApp", __name__)

from app.basketballApp import routes
