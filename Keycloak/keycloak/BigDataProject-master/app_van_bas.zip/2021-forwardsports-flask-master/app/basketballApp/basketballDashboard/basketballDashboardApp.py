import dash
import dash_core_components as dcc
import dash_html_components as html
import dash_bootstrap_components as dbc
from dash.dependencies import Input, Output

# from app import app
from .basketballApps import (
    overview,
    loadManagement,
    compose,
    comparison,
    select,
)  # , shooting


def init_dashboard(server):
    "Create the plotly Dash Football dashboard"
    basketball_app = dash.Dash(
        server=server,
        routes_pathname_prefix="/basketballDashApp/",
        external_stylesheets=[
            #'/static/dist/css/styles.css',
            #'https://fonts.googleapis.com/css?family=Lato',
            dbc.themes.BOOTSTRAP,
        ],
    )

    basketball_app.layout = html.Div(
        children=[
            html.H5("Orange Lions 3x3 Basketball", style={"textAlign": "center"}),
            # dcc.Tab(label='Overview', children=[
            #     overview.get_overview_layout(basketball_app),
            # ])
            dcc.Tabs(
                [
                    dcc.Tab(
                        label="Overview",
                        children=[
                            overview.get_overview_layout(basketball_app),
                        ],
                    ),
                    dcc.Tab(
                        label="Load Management",
                        children=[
                            loadManagement.get_loadManagement_layout(basketball_app),
                        ],
                    ),
                    dcc.Tab(
                        label="Compose",
                        children=[
                            compose.get_compose_layout(basketball_app),
                        ],
                    ),
                    dcc.Tab(
                        label="Select",
                        children=[
                            select.get_select_layout(basketball_app),
                        ],
                    ),
                    dcc.Tab(
                        label="Session Comparison",
                        children=[
                            comparison.get_comparison_layout(basketball_app),
                        ],
                    ),
                ]
            )
            #     ]),
            #
            #     dcc.Tab(label="Shooting / RightEye", children=[
            #         shooting.layout,
            #     ]),
            # ])
        ]
    )

    return basketball_app.server


# if __name__ == '__main__':
#     app.run_server(debug=True)
