from flask import render_template

from app.basketballApp import bp


@bp.route("/")
def home():
    """Landing page."""
    return render_template(
        "basketballApp/basketball_app.jinja2",
        title="Basketball Dashboard",
        description="Embed Plotly Dash into your Flask applications.",
        template="home-template",
        body="This is a homepage served with Flask.",
    )
