import logging
from logging.handlers import RotatingFileHandler
import os
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_bootstrap import Bootstrap
from flask_assets import Environment
from config import Config

db = SQLAlchemy()
migrate = Migrate()
bootstrap = Bootstrap()


def create_app(config_class=Config):
    app = Flask(__name__, instance_relative_config=False)
    app.config.from_object("config.Config")
    assets = Environment()

    assets.init_app(app)
    db.init_app(app)
    migrate.init_app(app, db)
    bootstrap.init_app(app)

    with app.app_context():
        # Import parts of our core Flask app
        from .basketballApp import routes
        from .basketballApp.assets import compile_static_assets

        #  Import Dash application
        from .basketballApp.basketballDashboard.basketballDashboardApp import (
            init_dashboard,
        )

        app = init_dashboard(app)

        # Compile static assets
        compile_static_assets(assets)

        from app.renameCsv import bp as rename_csv_bp

        app.register_blueprint(rename_csv_bp, url_prefix="/renameCsv")

        from app.basketballApp import bp as basketball_app_bp

        app.register_blueprint(basketball_app_bp)

        if not app.debug and not app.testing:

            if not os.path.exists("logs"):
                os.mkdir("logs")
            file_handler = RotatingFileHandler(
                "logs/wsgi.log", maxBytes=10240, backupCount=10
            )
            file_handler.setFormatter(
                logging.Formatter(
                    "%(asctime)s %(levelname)s: %(message)s "
                    "[in %(pathname)s:%(lineno)d]"
                )
            )
            file_handler.setLevel(logging.INFO)
            app.logger.addHandler(file_handler)

            app.logger.setLevel(logging.INFO)
            app.logger.info("wsgi startup")

        return app
